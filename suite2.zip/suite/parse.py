#!/usr/bin/env python3 -tt
from suite.payloads import *
import json
import re

jsondict = {}
jsonlist = []


def parse_logs(filename, writepath):
    log_to_ingest = writepath + ".json"
    with open(log_to_ingest, "w") as logjson:
        logjson.write("[")
    with open(log_to_ingest, "a") as logjson:
        valid = True
        if "messages" in filename or "syslog" in filename or "auth.log" in filename or "secure" in filename or "cron" in filename:
            with open(filename) as logfile:
                for entry in logfile:
                    match = re.match(
                        r"^([A-Z][a-z]{2})\s(\d{2})\s(\d{2}:\d{2}:\d{2})\s(\S+)\s?([^:]+)\[(\d+)\]:\s(.*)",
                        entry,
                    )
                    payload = None
                    if match:
                        fields = match.groups()
                        payload = build_syslog_pid_payload(fields)
                    else:
                        match = re.match(
                            r"^([^ ]+)\s+(\d{1,2})\s(\d{2}:\d{2}:\d{2})\s(\S+)\s?([^:]+)\[(\d+)\]:\s(.*)",
                            entry,
                        )
                        if match:
                            fields = match.groups()
                            payload = build_syslog_nopid_payload(fields)
                    if payload:
                        # need to reformat the timefield to a ISO standard format for elastic
                        jsonlist.append(json.dumps(payload))
                jsondict.clear()
        elif "audit" in filename:
            with open(filename) as logfile:
                for entry in logfile:
                    match = re.match(
                        r"", entry.strip()
                    )
                    if match:
                        fields = match.groups()
                        payload = build_audit_payload(fields)
                        jsonlist.append(json.dumps(payload))
        elif "dmesg" in filename:
            with open(filename) as logfile:
                for entry in logfile:
                    match = re.match(
                        r"^\[\s*([\d\.]+)\]\s+([^:]+):\s(.*)", entry.strip()
                    )
                    if match:
                        fields = match.groups()
                        payload = build_dmesg_payload(fields)
                        jsonlist.append(json.dumps(payload))
                jsondict.clear()
        elif "alternatives.log" in filename:
            with open(filename) as logfile:
                for entry in logfile:
                    if "--install" in entry:
                        match = re.match(
                            r"^update-alternatives\s+(\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}): run with --install (\S+) (\S+) (\S+) (\d+)((?: --slave \S+ \S+ \S+)+)?",
                            entry.strip(),
                        )
                        if match:
                            fields = match.groups()
                            payload = build_altinstall_payload(fields)
                            jsonlist.append(json.dumps(payload))
                    elif "link group" in entry:
                        match = re.match(
                            r"^update-alternatives\s+(\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}): link group (\S+) updated to point to (\S+)",
                            entry.strip(),
                        )
                        if match:
                            fields = match.groups()
                            payload = build_altupdate_payload(fields)
                            jsonlist.append(json.dumps(payload))
                jsondict.clear()
        elif "bootstrap.log" in filename:
            with open(filename) as logfile:
                for entry in logfile:
                    if "URL:" in entry:
                        match = re.match(
                            r"^(\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}) URL:(\S+) \[(\d+)/\d+\] -> \"([^\"]+)\" \[(\d+)\]",
                            entry.strip(),
                        )
                        if match:
                            fields = match.groups()
                            payload = build_bootapt_payload(fields)
                            jsonlist.append(json.dumps(payload))
                    elif "gpgv: " in entry:
                        match = re.match(
                            r"^gpgv: Signature made (.+)\ngpgv:\s+using (\S+) key (\S+)\ngpgv: Good signature from \"([^\"]+)\"",
                            entry.strip(),
                        )
                        if match:
                            fields = match.groups()
                            payload = build_bootgpg_payload(fields)
                            jsonlist.append(json.dumps(payload))
                    elif "dpkg: warning: " in entry:
                        match = re.match(
                            r"^dpkg: warning: parsing file '([^']+)' near line (\d+) package '([^']+)':\n missing '([^']+)' field",
                            entry.strip(),
                        )
                        if match:
                            fields = match.groups()
                            payload = build_bootwarn_payload(fields)
                            jsonlist.append(json.dumps(payload))
                    elif "dpkg: " in entry:
                        match = re.match(
                            r"^(?P<action>Selecting previously unselected package|Preparing to unpack|Unpacking|Setting up) (?P<package>[a-z0-9+.-]+)(?: \((?P<version>[^)]+)\))?",
                            entry.strip(),
                        )
                        if match:
                            fields = match.groups()
                            payload = build_bootdpkg_payload(fields)
                            jsonlist.append(json.dumps(payload))
                jsondict.clear()
        elif "dpkg.log" in filename and "unattended-upgrades-dpkg.log" not in filename:
            with open(filename) as logfile:
                for entry in logfile:
                    match = re.match(
                        r"^(\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}) (install|status|configure|upgrade) ([a-z0-9+.-]+):([a-z0-9]+) ([^\s]+)(?: ([^\s]+))?",
                        entry.strip(),
                    )
                    if match:
                        fields = match.groups()
                        payload = build_dpkg_payload(fields)
                        jsonlist.append(json.dumps(payload))
                jsondict.clear()
        elif "kern.log" in filename:
            with open(filename) as logfile:
                for entry in logfile:
                    match = re.match(
                        r"^(\w{3}\s+\d{1,2}\s+\d{2}:\d{2}:\d{2})\s+(\S+)\s+kernel:\s+\[[^\]]+\] (.+)",
                        entry.strip(),
                    )
                    if match:
                        fields = match.groups()
                        payload = build_kern_payload(fields)
                        jsonlist.append(json.dumps(payload))
                jsondict.clear()
        elif "apt/history.log" in filename:
            with open(filename) as logfile:
                entries = logfile.read()
                for entry in entries.split("\n\n"):
                    match = re.match(
                        r"Start-Date: (.+)\nCommandline: (.+)(?:\n)?(Install: (.+)(?:\n)?(Upgrade: (.+))?)(?:\n)?(Remove: (.+))?(?:\n)?(End-Date: (.+))",
                        entry.strip(),
                    )
                    if match:
                        fields = match.groups()
                        payload = build_apthist_payload(fields, entry)
                        jsonlist.append(json.dumps(payload))
                jsondict.clear()
        elif "cups/access_log" in filename:
            with open(filename) as logfile:
                for entry in logfile:
                    match = re.match(
                        r"^(\S+) - (\S+) \[([^\]]+)\] \"(\S+) (\S+) ([^\"]+)\" (\d{3}) (\d+) (\S+) (\S+)",
                        entry.strip(),
                    )
                    if match:
                        fields = match.groups()
                        payload = build_cups_payload(fields)
                        jsonlist.append(json.dumps(payload))
                jsondict.clear()
        else:
            print(f"\n [x] {filename} is not a recognized log file format.")
            valid = False
        if valid:
            json_entries = list(set(jsonlist))
            for each in json_entries[0:-1]:
                logjson.write(f"{each},")
            logjson.write(f"{json_entries[-1]}]")
            jsonlist.clear()

